package webSocketDateandTimeStamp;

import org.json.JSONObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import java.util.Date;
import java.util.logging.Level;

public class DateandTimeStamp {
	private static WebDriver driver;
	public static void main(String[] args) throws InterruptedException{
		
    	System.setProperty("webdriver.chrome.driver","/Applications/Eclipse/xyz/chromedriver");
        
        // To enable performance log for collecting network events
        LoggingPreferences loggingprefs = new LoggingPreferences();
        loggingprefs.enable(LogType.PERFORMANCE, Level.ALL);
        DesiredCapabilities cap = new DesiredCapabilities().chrome();
        cap.setCapability(CapabilityType.LOGGING_PREFS, loggingprefs);

       //To launch Google chrome browser
       driver = new ChromeDriver(cap);
       driver.navigate().to("file:///Users/mariappanvijayavelan/count.html");
       Thread.sleep(5000);
       LogEntries logEntries = driver.manage().logs().get(LogType.PERFORMANCE);
       
       //To get System's current DateandTimeStamp
       Date currentDate = new Date();
       System.out.println("current system date and time "+ currentDate);

       //To close the Chrome browser
        driver.close();
        driver.quit();
        

        logEntries.forEach(entry->{
            JSONObject messageJSON = new JSONObject(entry.getMessage());
            String method = messageJSON.getJSONObject("message").getString("method");
            if(method.equalsIgnoreCase("Network.webSocketFrameReceived")){
                System.out.println("System Date and Time: "+ currentDate);
            	System.out.println("Message Received: " + messageJSON.getJSONObject("message").getJSONObject("params").getJSONObject("response").getString("payloadData"));
                if (currentDate.equals(messageJSON.getJSONObject("message").getJSONObject("params").getJSONObject("response").getString("payloadData")))
                {
                	System.out.println("websocket sevice Date and time is equal to system time");
                }
                else{
                	
                	System.out.println("Date and Time is Mismatch");
                }
            }
         });
       
}    
}
